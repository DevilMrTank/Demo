//
//  XJAnnotationModel.h
//  Demo
//
//  Created by APPLE on 2021/6/3.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

#import "XJTrackModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface XJAnnotationModel : XJTrackModel <MKAnnotation>

@end

NS_ASSUME_NONNULL_END
