//
//  XJAnnotationModel.m
//  Demo
//
//  Created by APPLE on 2021/6/3.
//

#import "XJAnnotationModel.h"

@implementation XJAnnotationModel

@end
